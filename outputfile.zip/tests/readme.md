# Address Book

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install -r requirements.txt
```
Then run 
```python
python run.py
```
## Usage
Go to [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) for swagger UI